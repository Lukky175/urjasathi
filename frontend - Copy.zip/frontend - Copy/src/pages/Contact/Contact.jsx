function Contact() {
  return (
    <main>
      <h1>Contact Us</h1>
    </main>
  );
}

export default Contact;